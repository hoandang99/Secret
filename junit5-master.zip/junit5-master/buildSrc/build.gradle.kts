plugins {
	`kotlin-dsl`
}

repositories {
	mavenCentral()
}
